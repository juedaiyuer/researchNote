package com.lietu.vips;

import org.lobobrowser.html.domimpl.HTMLElementImpl;

public class NodeInfo {
	public HTMLElementImpl node;
	public int behaviorID;			//当前结点的behaviorID
}
