package com.lietu.vips;

import java.util.ArrayList;

public abstract class DividePolicy {
	abstract public ArrayList divideNode(CHTMLNode node,NodePool pool,int pDOC);
}
